package com.example.hm_1_month7

import androidx.recyclerview.widget.RecyclerView.Adapter

class AdapterTab {
}